abstract class PaymentMethod {
  void pay(double amount);
  String paymentDetails();
}